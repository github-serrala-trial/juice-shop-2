---
name: "\U0001F680Feature request"
about: Suggest a feature for OWASP Juice Shop
title: '[🚀] '
labels: feature
assignees: ''

---

<!--🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅

To expedite issue processing please search open and closed issues before submitting a new one.
Existing issues often contain information about workarounds, resolution, or progress updates.

🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅🔅-->

# :rocket: Feature request

### Description

<!-- ✍️--> A clear and concise description of the problem or missing capability...


### Solution ideas

<!-- ✍️--> If you have a solution in mind, please describe it.


### Possible alternatives

<!-- ✍️--> Have you considered any alternative solutions or workarounds?